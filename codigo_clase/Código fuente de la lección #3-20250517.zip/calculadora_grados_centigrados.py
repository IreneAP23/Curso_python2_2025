# Este programa me permite calcular la cantidad de grados centígrados
# a partir de una cantidad x de grados Farenheit
# Calculadora de Farenheit a Celcius

# Autor: Luis Villagra
# Fecha de creación: 08/04/2025
# Versión 1.0

"""
Fórmula de grados Farenheit a grados Celcius

    => ( Grados Farenheit - 32 ) * 5 / 9 = Grados Celcius
"""

# grados_farenheit = input("Ingrese la cantidad de grados Farenheit que desea convertir: ")
# grados_farenheit = float(grados_farenheit)

grados_farenheit = float(input("Ingrese la cantidad de grados Farenheit que desea convertir: "))

grados_celcius = (grados_farenheit - 32) * 5 / 9

print("La cantidad de grados Farenheit corresponden a", grados_celcius,"grados celcius.")
