
nombre = "Juan Perez"
print( type(nombre) )

edad = 35
salario = 250145.00
trabaja = True
estadocivil = None

nombre = 25.69
print( type(nombre) )

