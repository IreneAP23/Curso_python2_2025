from inspect import currentframe, getframeinfo

f = currentframe()

nombre = "Juan Perez"
print( getframeinfo(f).lineno, type(nombre) )

edad = 35
salario = 250145.00
trabaja = True
estadocivil = None

nombre = 25.69
print(getframeinfo(f).lineno, type(nombre) )