
nombre = "Juan Pérez"
nombre = "María Salas"
print(nombre)