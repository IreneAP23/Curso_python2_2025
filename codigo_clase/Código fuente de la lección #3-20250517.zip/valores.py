
pass
resultado = 5 * 8

sumando1 = 41
sumando2 = 35

resultado_suma = sumando1 + sumando2

pass