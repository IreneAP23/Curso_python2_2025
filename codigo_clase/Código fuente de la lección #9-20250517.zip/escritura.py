ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"

# len(provincias_cr) - 1 = 7 - 1 = 6
provincias_cr = [
    "San José", # 0
    "Alajuela", # 1
    "Cartago",  # 2
    "Heredia",  # 3
    "Guanacaste", # 4
    "Puntarenas", # 5
    "Limón" # 6
]    

archivo = open( ruta, mode="w", encoding="utf-8" )

#archivo.write("Hola a todos desde Python!\n")
#archivo.write("Generado desde Python")


# for provincia in provincias_cr:
#     archivo.write( f"{provincia}\n" )

for index, provincia in enumerate(provincias_cr):
    if index < len(provincias_cr) - 1:
        archivo.write( f"{provincia}\n" )
    else:
        archivo.write( f"{provincia}" )

