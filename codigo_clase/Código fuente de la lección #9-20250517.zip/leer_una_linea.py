ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"

archivo = open( ruta, mode="r", encoding="utf-8" )

while True:

    linea = archivo.readline()
    if linea == "":
        break
    else:
        print(linea, end="")

print()