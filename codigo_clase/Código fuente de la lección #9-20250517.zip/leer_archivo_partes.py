ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"

archivo = open( ruta, mode="r", encoding="utf-8" )

tamanyo_chunks = 20 # Tamaño del segmento de texto a leer
while True:

    linea = archivo.read(tamanyo_chunks)

    if linea == "":
        break
    else:
        print(linea, end="")

print()
