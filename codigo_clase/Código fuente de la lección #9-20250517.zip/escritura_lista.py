ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"


provincias_cr = [
    "San José\n",
    "Alajuela\n",
    "Cartago\n", 
    "Heredia\n", 
    "Guanacaste\n",
    "Puntarenas\n",
    "Limón"
]    

archivo = open( ruta, mode="w", encoding="utf-8" )

archivo.writelines(provincias_cr)
