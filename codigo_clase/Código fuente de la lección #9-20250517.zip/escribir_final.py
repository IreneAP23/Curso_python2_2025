ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"


archivo = open( ruta, mode="a", encoding="utf-8" )

archivo.write("Pérez Zeledón\n")