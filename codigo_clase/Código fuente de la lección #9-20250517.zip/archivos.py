"""

# MODOS DE TEXTO
r : Solo Lectura                                                        rt
w : Solo Escritura => Sobreescritura                                    wt
x : Solo creación                                                       xt
a : Solo Escritura => Agrega información al final => No sobreescribe    at
r+ : Leer con la posibilidad de escribir                                rt+
w+ : Escribir con la posibilidad de leer => Sobreescribe                wt+
a+ : Escribir con la posibilidad de leer => No sobreescribe             at+

# MODOS BINARIOS

rb
wb
xb
ab
rb+
wb+
ab+
"""



ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"

archivo = open( ruta, mode="r", encoding="utf-8" )

print("Primera lectura e impresión")
contenido = archivo.read(10) 
print(contenido)
print("-----------------------------------------------")
print("Segunda lectura lectura e impresión")
contenido = archivo.read(15) 
print(contenido)
print("-----------------------------------------------")

archivo.close()
