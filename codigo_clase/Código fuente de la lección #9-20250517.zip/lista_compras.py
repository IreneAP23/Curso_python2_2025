
ruta = "/home/luis/Downloads/Manejo de archivos/lista_compras.super"

archivo = open(ruta, mode="a", encoding="iso-8859-1")

while True:

    articulo = input("Ingrese el nombre del artículo que desea agregar a la lista de compras: N para salir: ")
    if articulo == "N":
        break

    archivo.write( f"{articulo}\n" )


archivo.close()
