ruta = "/home/luis/Downloads/Manejo de archivos/provincias_costa_rica.txt"

archivo = open( ruta, mode="r", encoding="utf-8" )


lineas = archivo.readlines()

for indice, provincia in enumerate(lineas, 1):
    texto = f"{indice}) {provincia}"
    print(texto, end="")

print()