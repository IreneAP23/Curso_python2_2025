
ciudades = ["San José", "Cartago", "Heredia", "Limón", "Puntarenas"]
temperaturas = [22.5, 20.0, 21.3, 27.8, 26.2]


tamanyo_listas = len(ciudades)

print("---------------------------------------------------------------------------")
print("GESTOR DE TEMPERATURAS")
print("---------------------------------------------------------------------------")

for indice, ciudad in enumerate(ciudades):
    print( "La ciudad de", ciudad, "registra un temperatura de", temperaturas[indice], "grados celcius")

print("---------------------------------------------------------------------------")


# Iniciamos en None asumiendo que la lista está vacía
temperatura_maxima = None
temperatura_minima = None

if tamanyo_listas > 0:
    temperatura_maxima = max(temperaturas)
    temperatura_minima = min(temperaturas)


# Se crean dos listas vacías, una para las ciudades con temperatura igual a la temperatura máxima
# y una para las que tienen la temperatura igual a la mínima
ciudades_temp_max = []
ciudades_temp_min = []

for indice, temp in enumerate(temperaturas):

    # Recorremos las temperaturas, utilizando enumerate para obtener el índice
    # y con él obtener la ciudad

    if temp == temperatura_maxima:
        # Si la temperatura es igual a la máxima, entonces obtenemos la ciudad con el
        # índice y la agregamos al listado de ciudades con la temperatura igual a la máxima
        ciudad = ciudades[indice]
        ciudades_temp_max.append(ciudad)
    
    if temp == temperatura_minima:
        # Si la temperatura es igual a la mínima, entonces obtenemos la ciudad con el
        # índice y la agregamos al listado de ciudades con la temperatura igual a la mínima
        ciudad = ciudades[indice]
        ciudades_temp_min.append(ciudad)


suma_total_temperaturas = sum(temperaturas)

# Calculamos el promedio dividiendo
promedio = suma_total_temperaturas / tamanyo_listas



# Se crean dos listas vacías, una para las ciudades con temperatura sobre el promedio
# y una para las que tienen la temperatura por debajo del promedio
ciudades_encima_promedio = []
ciudades_debajo_promedio = []


for indice, temp in enumerate(temperaturas):

    # Recorremos las temperaturas, utilizando enumerate para obtener el índice
    # y con él obtener la ciudad

    ciudad = ciudades[indice] # Obtenemos la ciudad

    # Dependiendo de la temperatura agregamos a la lista correspondiente
    if temp > promedio:        
        ciudades_encima_promedio.append(ciudad)
    else:
        ciudades_debajo_promedio.append(ciudad)