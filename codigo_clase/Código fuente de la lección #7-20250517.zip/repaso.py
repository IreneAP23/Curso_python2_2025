

tupla = ( "lunes", "martes", "miércoles" )
#            0         1         2
#           -3        -2         -1

lista = [ "gato", "perro", "caballo" ]
#            0        1          2
#           -3        -2         -1



for elemento in lista:
    pass