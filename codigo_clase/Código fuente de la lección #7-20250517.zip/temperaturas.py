
ciudades = ["San José", "Cartago", "Heredia", "Limón", "Puntarenas"]
temperaturas = [22.5, 20.0, 21.3, 27.8, 26.2]


tamanyo_listas = len(ciudades)


print("---------------------------------------------------------------------------")
print("GESTOR DE TEMPERATURAS")
print("---------------------------------------------------------------------------")

for indice in range(0, tamanyo_listas): # 0  1 2 3 4    
    print( "La ciudad de", ciudades[indice], "registra un temperatura de", temperaturas[indice], "grados celcius")

print("---------------------------------------------------------------------------")



# Iniciamos en None asumiendo que la lista está vacía
temperatura_maxima = None
temperatura_minima = None


if tamanyo_listas > 0:
    # Si la lista tiene al menos un elemento, consideramos el primer elemento
    # como la temperatura máxima y mínima
    temperatura_maxima = temperaturas[0]
    temperatura_minima = temperaturas[0]


for temp in temperaturas:
    # Revisamos cada temperatura
    if temp > temperatura_maxima:
        # Si la temperatura es mayor a la que tenemos registrada como máxima, entonces
        # esas temperatura se vuelve la máxima
        temperatura_maxima = temp

    if temp < temperatura_minima:
        # Si la temperatura es menor a la que tenemos registrada como mínima, entonces
        # esas temperatura se vuelve la mínima
        temperatura_minima = temp


# Se crean dos listas vacías, una para las ciudades con temperatura igual a la temperatura máxima
# y una para las que tienen la temperatura igual a la mínima
ciudades_temp_max = []
ciudades_temp_min = []

for indice, temp in enumerate(temperaturas):

    # Recorremos las temperaturas, utilizando enumerate para obtener el índice
    # y con él obtener la ciudad

    if temp == temperatura_maxima:
        # Si la temperatura es igual a la máxima, entonces obtenemos la ciudad con el
        # índice y la agregamos al listado de ciudades con la temperatura igual a la máxima
        ciudad = ciudades[indice]
        ciudades_temp_max.append(ciudad)
    
    if temp == temperatura_minima:
        # Si la temperatura es igual a la mínima, entonces obtenemos la ciudad con el
        # índice y la agregamos al listado de ciudades con la temperatura igual a la mínima
        ciudad = ciudades[indice]
        ciudades_temp_min.append(ciudad)


suma_total_temperaturas = 0 # Acumulador
for temp in temperaturas:
    # Pasamos por cada temperatura y la sumamos en el acumulador
    suma_total_temperaturas = suma_total_temperaturas + temp

# Calculamos el promedio dividiendo
promedio = suma_total_temperaturas / tamanyo_listas



# Se crean dos listas vacías, una para las ciudades con temperatura sobre el promedio
# y una para las que tienen la temperatura por debajo del promedio
ciudades_encima_promedio = []
ciudades_debajo_promedio = []


for indice, temp in enumerate(temperaturas):

    # Recorremos las temperaturas, utilizando enumerate para obtener el índice
    # y con él obtener la ciudad

    ciudad = ciudades[indice] # Obtenemos la ciudad

    # Dependiendo de la temperatura agregamos a la lista correspondiente
    if temp > promedio:        
        ciudades_encima_promedio.append(ciudad)
    else:
        ciudades_debajo_promedio.append(ciudad)



print("--- Resumen de Temperaturas ---")
print("Temperatura Más Alta:", temperatura_maxima, "grados Celsius en: ", ciudades_temp_max)
print("Temperatura Más Baja:", temperatura_minima, "grados Celsius en: ", ciudades_temp_min)
print("Temperatura Promedio General:", promedio)
print("Ciudades con Temperatura Por Encima del Promedio:", ciudades_encima_promedio)
print("Ciudades con Temperatura Por Debajo del Promedio:", ciudades_debajo_promedio)
print("----------------------------")
