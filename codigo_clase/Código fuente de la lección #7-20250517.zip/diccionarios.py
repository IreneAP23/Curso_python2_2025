

datos_personales = {

    "nombre" : "Juan",
    "apellidos": "Pérez",
    "edad": 25,
    "trabaja": False,
    "estudia": False,
    "nombre": "Erick"
}


print( datos_personales["apellidos"]  )




