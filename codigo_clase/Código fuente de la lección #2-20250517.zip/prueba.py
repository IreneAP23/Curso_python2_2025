import time

mensaje = "Bienvenidos a Python!. Python es un lenguaje bonito"

while True:
    print(mensaje)
    time.sleep(2)




