print("Hola a todos","Bievenidos a Python",8/2*4/16)
print("-----------------------------------------------")