"Bienvenidos a Python!. Python es un lenguaje bonito"
'Bienvenidos a Python!. Python es un lenguaje bonito'