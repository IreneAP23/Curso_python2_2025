

edad = 34
nombre_persona = "Juan"
anyo_nacimiento = 1990